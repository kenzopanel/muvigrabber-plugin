<?php

require_once(MUVI_PATH . 'controllers/DashboardController.php');
require_once(MUVI_PATH . 'controllers/MovieController.php');

/*
|--------------------------------------------------------------------------
| Scrape Content
|--------------------------------------------------------------------------
*/

function scrape($type, $url, $sitename)
{
    switch ($type) {
        case 'dashboard':
            switch ($sitename) {
                case 'lk21':
                case 'nonton-drama':
                    return lk21ListScrape($url, $sitename);
                    break;

                default:
                    wp_die('Terjadi kesalahan. Sitename tidak terdefinisi');
                    break;
            }
            break;

        case 'get':
        case 'post':
            switch ($sitename) {
                case 'lk21':
                    return lk21Scrape($url);
                    break;

                case 'nonton-drama':
                    return nontonDramaScrape($url);
                    break;

                case 'nonton-drama-alleps':
                    return nontonDramaScrape($url, true);
                    break;

                case 'nonton-drama-eps':
                    return nontonDramaScrapeEps($url);
                    break;

                default:
                    wp_die('Terjadi kesalahan. Sitename tidak terdefinisi');
                    break;
            }
            break;
        default:
            wp_die('Terjadi kesalahan. Type tidak terdefinisi');
            break;
    }
}
