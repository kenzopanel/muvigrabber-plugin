jQuery(document).ready(function ($) {
    const path = window.location.href.split('/');

    function callAjax(type, params = null) {
        let url = muvigrabber.ajax_url,
            method = 'POST',
            postData = {};

        if (type === 'verify_api') {
            url = `http://autopost-api.test/api/v1/client/${params}`;
            method = 'GET';
        } else {
            postData = {
                security: muvigrabber.ajax_nonce,
                action: 'send_form',
                type: type,
            }

            if (type === 'get_data') {
                postData.data = params;
            } else if (type === 'scrape') {
                postData.url = params.url;
                postData.sitename = params.sitename;
            } else if (type === 'upload_post') {
                postData.post_type = params.post_type;
                postData.url = params.url;
                if (params.clipboard) {
                    postData.clipboard = params.clipboard;
                }
            } else if (type === 'get_post') {
                postData.source = params.source;
                postData.url = params.url;
            }
        }

        return new Promise((resolve, reject) => {
            jQuery.ajax({
                type: method,
                url: url,
                data: postData,
                cache: false,
                async: true,
                success: function (response) {
                    resolve(response);
                },
                error: function (err) {
                    alert('There is some error. Please check browser console');
                    console.error(err);
                    reject(err);
                }
            });
        })
    }

    function scrape(url, sitename) {
        if (!url || url === null) {
            alert('There is some error. Please check browser console');
            console.error('Gagal mendapatkan data dari server API');
            return false;
        }

        callAjax('scrape', {
            url: url,
            sitename: sitename
        }).then(
            (scrape) => {
                muvi_add_content(scrape);
            }
        );
    }

    function itemContent(title, link, poster, slug, eps = null) {
        if (eps) {
            return `<div class="col-md-125" data-slug="${slug}"> <div class="gmr-item-modulepost"> <img width="152" height="228" src="https:${poster}" class="attachment-medium size-medium wp-post-image"> <div class="last-episode">EPS<span>${eps}</span></div> <div class="entry-header text-center"> <div class="gmr-button-widget"> <div class="clearfix gmr-popup-button-widget"> <button type="button" class="btn btn-sm btn-primary gmr-add-btn">Tambah</button> </div><div class="clearfix"> <a href="${link}" class="btn btn-sm gmr-view-btn" target="_blank">Lihat</a> </div></div><h2 class="entry-title">${title}</h2> </div></div></div>`;
        }

        return `<div class="col-md-125" data-slug="${slug}"> <div class="gmr-item-modulepost"> <img width="152" height="228" src="https:${poster}" class="attachment-medium size-medium wp-post-image"> <div class="entry-header text-center"> <div class="gmr-button-widget"> <div class="clearfix gmr-popup-button-widget"> <button type="button" class="btn btn-sm btn-primary gmr-add-btn">Tambah</button> </div><div class="clearfix"> <a href="${link}" class="btn btn-sm gmr-view-btn" target="_blank">Lihat</a> </div></div><h2 class="entry-title">${title}</h2> </div></div></div>`;
    }

    function verify_api(callback) {
        callAjax('get_api').then(
            (api_key) => {
                let is_fail = false;
                if (api_key !== null || api_key !== '' || api_key !== 0) {
                    callAjax('verify_api', api_key).then(
                        (verify_api) => {
                            if (verify_api && verify_api.success === true) {
                                let host = `${path[0]}//${path[2]}`;

                                let web = verify_api.data.web.map(function (el) {
                                    return el.domain;
                                });

                                if (web.includes(host)) {
                                    callback(verify_api.data.source);
                                } else {
                                    is_fail = true;
                                }
                            }
                        }
                    );
                } else {
                    is_fail = true;
                }

                if (is_fail) {
                    $('#muvigrab-content').html('<p class="text-base font-medium">Gagal melakukan verifikasi API Key</p>');
                }
            },
            (err) => {
                alert('Gagal mendapatkan API Key');
                $('#muvigrab-content').html('<p class="text-base font-medium">Gagal melakukan verifikasi API Key</p>');
                console.error(err);
            }
        );
    }

    let cart = [],
        MOVIE_HOST = null,
        MOVIE_SITENAME = null,
        TV_HOST = null,
        TV_SITENAME = null,
        posttype = 'movie';

    if (path[3] === 'wp-admin' && path[4] === 'admin.php?page=muvigrabber') {
        verify_api((source) => {
            callAjax('get_data', source).then(
                (get_data) => {
                    if (get_data && get_data.movie) {
                        MOVIE_HOST = get_data.movie.host;
                        MOVIE_SITENAME = get_data.movie.sitename;
                        TV_HOST = get_data.tv.host;
                        TV_SITENAME = get_data.tv.sitename;

                        scrape(MOVIE_HOST, MOVIE_SITENAME);
                    } else {
                        $('#muvigrab-content').html('<p class="text-base font-medium">Gagal melakukan verifikasi API Key</p>');
                    }
                }
            );
        });
    } else if (path[3] === 'wp-admin' && path[4] === 'admin.php?page=muvigrabber-settings') {
        let movie = $('#type').attr('data-movie');
        let tv = $('#type').attr('data-tv');

        $(`select[name="movie"] option[value="${movie}"]`).prop('selected', true);
        $(`select[name="tv"] option[value="${tv}"]`).prop('selected', true);
    } else if (path[3] === 'wp-admin' && path[4].includes('post.php')) {
        verify_api((source) => {
            if (source) {
                source.forEach(el => {
                    $('#source').append(`<option value="${el.sitename}">${el.name}</option>`);
                });
            } else {
                alert('Gagal mendapatkan data dari server API')
            }
        });
    }

    function muvi_add_content(data) {
        if (data && Array.isArray(data)) {
            $('#muvigrab-content').empty();
            data.forEach(function (el) {
                let slug = el.link.trim().split('/')[3];
                let title = el.title.trim().replace("/\t/g", ' ');
                let html;
                if (posttype === 'movie') {
                    html = itemContent(title, el.link.trim(), el.poster.trim(), slug);
                } else if (posttype === 'tv') {
                    html = itemContent(title, el.link.trim(), el.poster.trim(), slug, el.eps.trim());
                }

                $('#muvigrab-content').append(html);
            });

            $('#muvigrab-content').removeClass('justify-content-center');
        }
    }

    function changeType(e) {
        $(e).siblings('.btn-active').removeClass('btn-active').addClass('btn-option').prop('disabled', false);
        $(e).removeClass('btn-option').addClass('btn-active').prop('disabled', true);
        posttype = $(e).data('type');
        $('#muvigrab-content').empty().addClass('justify-content-center').html('<span class="loader"></span>');
        $('.tv-alert').addClass('hide');
        $('.clipboard-alert').addClass('hide');
        $('#upload-post').removeClass('hide');
        $('#result').addClass('hide');
        $('#result').empty();

        if (posttype !== 'clipboard') {
            $('#clipboard-wrapper').addClass('hide');
        }

        if (posttype === 'movie') {
            scrape(MOVIE_HOST, MOVIE_SITENAME);
        } else if (posttype === 'tv') {
            $('.tv-alert').removeClass('hide');
            scrape(TV_HOST, TV_SITENAME);
        } else {
            $('.clipboard-alert').removeClass('hide');
            $('#upload-post').addClass('hide');
            $('#muvigrab-content').empty();
            $('#clipboard-wrapper').removeClass('hide');
        }
    }

    $(document).on('click', '#posttype-opt .btn', function () {
        let total = $('#upload-post .total');

        if (total.text() > 0) {
            if (confirm('Mengubah post type akan menghapus item yang telah ditambahkan')) {
                total.text('0');
                cart = [];
                changeType(this);
            }
        } else {
            changeType(this);
        }
    });

    $(document).on('click', '.gmr-add-btn', function (event) {
        let slug = $(this).closest('.col-md-125').attr('data-slug'),
            hasAdded = event.target.classList.contains('added');

        if (hasAdded) {
            let index = cart.indexOf(slug);
            cart.splice(index, 1);

            $(this).removeClass('added').text('Tambah');
        } else {
            cart.push(slug);
            $(this).addClass('added').text('Hapus');
        }

        // console.log(cart);
        let total = cart.length;
        $('#upload-post .total').text(total);
    });

    function uploadedCb(upload, length, i) {
        if (upload && upload.success) {
            let data = upload.data;
            $('#result').append(`<p class='text-base text-success'><span class='font-medium'>Sukses</span> menambah konten ${data.title}</p>`);
            if (data.eps) {
                if (data.eps.error) {
                    $('#result').append(`<p class='text-base text-danger'><span class='font-medium'>Gagal</span> ${data.eps.error}</p>`);
                } else if (data.eps.title) {
                    $('#result').append(`<p class='text-base text-success'><span class='font-medium'>Sukses</span> menambah konten ${data.eps.title}</p>`);
                } else {
                    if (data.eps[0].title || data.eps[0].error) {
                        data.eps.forEach(e => {
                            if (e.error) {
                                $('#result').append(`<p class='text-base text-danger'><span class='font-medium'>Gagal</span> ${e.error}</p>`);
                            } else {
                                $('#result').append(`<p class='text-base text-success'><span class='font-medium'>Sukses</span> menambah konten ${e.title}</p>`);
                            }
                        });
                    }
                }
            }
        } else if (upload.data && !upload.success) {
            $('#result').append(`<p class='text-base text-danger'><span class='font-medium'>Gagal</span> ${upload.data}</p>`);
        } else {
            $('#result').append("<p class='text-base text-danger'><span class='font-medium'>Gagal</span> Cek browser console</p>");
            console.error(upload);
        }

        if (length == i + 1) {
            $('#upload-post').html('Upload Post (<span class="total">0</span>)');
            $('#upload-post').prop('disabled', false);

            $('#upload-clipboard').html('Upload Post');
            $('#upload-clipboard').prop('disabled', false);
        }
    }

    $('#upload-post').click(function () {
        if (cart.length > 0) {
            $(this).html('<span class="loader loader-sm"></span> Uploading...');
            $(this).prop('disabled', true);

            cart.forEach((slug, i) => {
                if (posttype === 'movie') {
                    callAjax('upload_post', {
                        post_type: 'movie',
                        url: `${MOVIE_HOST}/${slug}`,
                    }).then(
                        (upload) => {
                            uploadedCb(upload, cart.length, i);
                        }
                    );
                } else {
                    callAjax('upload_post', {
                        post_type: 'tv',
                        url: `${TV_HOST}/${slug}`,
                    }).then(
                        (upload) => {
                            uploadedCb(upload, cart.length, i);
                        }
                    );
                }

                if (i == 0) {
                    $('#result').removeClass('hide');
                }
            });
        } else {
            alert('Belum ada item yang ditambahkan');
        }
    });

    $('#upload-clipboard').click(function () {
        let post_type = $('#post-type').val(),
            links = $('#link').val(),
            linkArr = links.split(/\r?\n/);

        if (post_type && links) {
            $(this).html('Uploading...');
            $(this).prop('disabled', true);

            linkArr.forEach((link, i) => {
                if (posttype === 'movie') {
                    callAjax('upload_post', {
                        post_type: 'movie',
                        url: link,
                        clipboard: true,
                    }).then(
                        (upload) => {
                            uploadedCb(upload, linkArr.length, i);
                        }
                    );
                } else {
                    callAjax('upload_post', {
                        post_type: 'tv',
                        url: link,
                        clipboard: true,
                    }).then(
                        (upload) => {
                            uploadedCb(upload, linkArr.length, i);
                        }
                    );
                }

                if (i == 0) {
                    $('#result').removeClass('hide');
                }
            });
        } else {
            alert('Masukkan post type dan link');
        }
    });

    $('#update').click(function () {
        let post_type = $('#post-type').val(),
            source = $('#source').val(),
            url = $('#url').val();

        if (post_type && source && url) {
            if (post_type == 'episode') {
                source = `${source}-eps`;
            }

            callAjax('get_post', {
                source: source,
                url: url,
            }).then(
                (data) => {
                    if (post_type !== 'tv') {
                        if (data.stream) {
                            data.stream.forEach((st, i) => {
                                if (i <= 8) {
                                    $(`#opsi-title-player${i}`).val(st.player);
                                    $(`#opsi-player${i}`).val(st.link);
                                }
                            });
                        }

                        if (data.download) {
                            data.download.forEach((dl, i) => {
                                if (i <= 8) {
                                    $(`#opsi-title-download${i}`).val(dl.server);
                                    $(`#opsi-download${i}`).val(dl.link);
                                }
                            });
                        }
                    }
                }
            );
        } else {
            alert('Masukkan post type, sumber konten, dan link');
        }
    })
});