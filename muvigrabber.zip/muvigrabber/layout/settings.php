<link rel="stylesheet" href="<?= MUVI_URL . 'assets/bootstrap.min.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/muvigrabber.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/style.css' ?>">
<div class="wrap">
    <h1 class="text-slate-800 text-[2rem] leading-10 pb-3 font-semibold text-left wp-heading-inline">Muvi Grabber</h1>
    <hr class="wp-header-end">
    <main>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-none d-md-block">
            <form action="<?= esc_html(admin_url('admin-post.php')); ?>" method="POST">
                <?php
                wp_nonce_field('acme-settings-save', 'acme-custom-message');
                ?>
                <section class="border-b border-solid border-slate-200 px-8 py-8 justify-between">
                    <div class="mr-16 w-full flex items-center">
                        <h3 class="p-0 flex-1 justify-right inline-flex text-xl leading-6 font-semibold text-slate-800">Auto Update Post</h3>
                        <input class="form-check-input m-0" type="checkbox" name="autoupdate" id="autoupdate" <?= $auto ?>>
                    </div>
                    <p class="mt-2 w-9/12 text-sm text-slate-500 tablet:w-full">Centang untuk menambahkan postingan terbaru secara otomatis</p>
                </section>
                <section class="border-b border-solid border-slate-200 px-8 py-8 justify-between">
                    <div class="mr-16 w-full flex">
                        <div class="flex flex-column flex-1">
                            <h3 class="p-0 justify-right inline-flex text-xl leading-6 font-semibold text-slate-800">Sumber Postingan</h3>
                            <p class="mt-2 w-9/12 text-sm text-slate-500 tablet:w-full">Pilih sumber postingan</p>
                        </div>
                        <div id="type" class="flex flex-column gap-3" data-movie="<?= $movie ?>" data-tv="<?= $tv ?>" style="min-width:20%">
                            <div class="form-group">
                                <label for="">Movie</label>
                                <select name="movie" class="form-select mt-1" required>
                                    <option value="" disabled selected>- Movie -</option>
                                    <option value="lk21">LK21</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">TV dan Episode</label>
                                <select name="tv" class="form-select mt-1" required>
                                    <option value="" disabled selected>- TV & Eps -</option>
                                    <option value="nonton-drama">Nonton Drama</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="border-b border-solid border-slate-200 px-8 py-8 justify-between">
                    <div class="mr-16 w-full flex items-center">
                        <h3 class="p-0 flex-1 justify-right inline-flex text-xl leading-6 font-semibold text-slate-800">API Key</h3>
                        <input type="text" id="apikey" name="apikey" autocomplete="off" value="<?= $key ?>" required style="min-width:50%">
                    </div>
                    <p class="mt-2 w-9/12 text-sm text-slate-500 tablet:w-full">Masukkan API Key Anda</p>
                </section>
                <section class="border-b border-solid border-slate-200 px-8 py-8 justify-between">
                    <div class="mr-16 w-full flex items-center">
                        <h3 class="p-0 flex-1 justify-right inline-flex text-xl leading-6 font-semibold text-slate-800">Proxy</h3>
                    </div>
                    <p class="mt-2 w-9/12 text-sm text-slate-500 tablet:w-full">Masukkan List Proxy</p>
                    <div class="form-group mt-3">
                        <textarea class="form-control" name="proxy" id="proxy" cols="30" rows="10" placeholder="host:port@username:password
host:port"><?= $proxy ?></textarea>
                    </div>
                </section>
                <button type="submit" class="btn btn-primary btn-sm mt-3 px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white">Simpan Perubahan</button>
            </form>
        </div>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-sm-block d-md-none">
            <p class="text-slate-800 text-lg font-semibold text-center">Fitur ini hanya tersedia pada mode Landscape</p>
        </div>
    </main>
</div>