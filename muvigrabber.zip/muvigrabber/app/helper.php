<?php

require_once(ABSPATH . 'wp-admin/includes/image.php');

/*
|--------------------------------------------------------------------------
| CURL Settings
|--------------------------------------------------------------------------
*/

function getContent($url, $cookie = false, $slug = false)
{
    $proxy = get_option('muvigrabber_proxy');
    $header = [
        "Upgrade-Insecure-Requests: 1",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
        "Accept: */*",
        "Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,ms;q=0.6",
    ];

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLINFO_HEADER_OUT, true);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 120);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_COOKIEJAR, MUVI_PATH . 'assets/cookie.txt');

    if ($proxy) {
        $proxiesArr = unserialize($proxy);
        if (!empty($proxiesArr[0])) {
            $index = array_rand($proxiesArr, 1);
            $getProxy = $proxiesArr[$index];
            $proxyArr = explode('@', $getProxy);
            $proxyHost = $proxyArr[0];
            curl_setopt($curl, CURLOPT_PROXY, $proxyHost);

            if (isset($proxyArr[1])) {
                $proxyPwd = $proxyArr[1];
                curl_setopt($curl, CURLOPT_PROXYUSERPWD, $proxyPwd);
            }
        }
    }

    if ($cookie && $slug) {
        $header[] = "cookie: validate=$cookie";
        curl_setopt(
            $curl,
            CURLOPT_POSTFIELDS,
            ['slug' => $slug]
        );
    }

    curl_setopt(
        $curl,
        CURLOPT_HTTPHEADER,
        $header
    );

    $html = curl_exec($curl);

    if (curl_errno($curl)) {
        wp_die(curl_error($curl));
    } else {
        return $html;
    }

    curl_close($curl);
}

/*
|--------------------------------------------------------------------------
| Get Post Data
|--------------------------------------------------------------------------
*/

function getPost($title, $type)
{
    $post = get_posts([
        'title' => $title,
        'post_type' => $type,
        'post_status' => 'publish',
    ])[0];
    if (!$post) return null;
    return $post;
}

/*
|--------------------------------------------------------------------------
| Convert String to Slug
|--------------------------------------------------------------------------
*/

function slugify($str, $delimiter = '-')
{

    $slug = strtolower(trim(preg_replace('/[\s-]+/', $delimiter, preg_replace('/[^A-Za-z0-9-]+/', $delimiter, preg_replace('/[&]/', 'and', preg_replace('/[\']/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $str))))), $delimiter));
    return $slug;
}

/*
|--------------------------------------------------------------------------
| Download & Upload Image to Storage
|--------------------------------------------------------------------------
*/

function downloadImage($url)
{
    $arrContextOptions = array(
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
        ),
    );

    $extension = explode('.', explode('?', array_pop(explode('/', $url)))[0])[1];
    $filename = time() . '.' . $extension;
    $path = wp_upload_dir()['path'] . '/' . $filename;
    file_put_contents($path, file_get_contents($url, false, stream_context_create($arrContextOptions)));
    return $path;
}

/*
|--------------------------------------------------------------------------
| Set Post Thumbnail
|--------------------------------------------------------------------------
*/

function setThumbnail($filepath, $parent_id)
{
    $attachment = array(
        'post_mime_type' => 'image/jpeg',
        'post_title' => basename($filepath),
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $filepath, $parent_id);
    set_post_thumbnail($parent_id, $attach_id);

    $attach_data = wp_generate_attachment_metadata($attach_id, $filepath);
    wp_update_attachment_metadata($attach_id, $attach_data);
}

/*
|--------------------------------------------------------------------------
| Set Post Meta Data
|--------------------------------------------------------------------------
*/

function check_meta_terms($post, $callback, $key, $value)
{
    if (isset($value) && !empty($value)) {
        if ($callback === 'add_post_meta') {
            add_post_meta($post, $key, $value);
        } elseif ($callback === 'wp_set_post_terms') {
            wp_set_post_terms($post, $value, $key);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Send success data to user
|--------------------------------------------------------------------------
*/

function muvi_send_success($data)
{
    return [
        'success' => true,
        'data' => $data
    ];
}

/*
|--------------------------------------------------------------------------
| Send error data to user
|--------------------------------------------------------------------------
*/

function muvi_send_error($data)
{
    return [
        'success' => false,
        'data' => $data
    ];
}

/*
|--------------------------------------------------------------------------
| Log uploaded content
|--------------------------------------------------------------------------
*/

function muvi_logger($link, array $data)
{
    $return = false;
    $message = $data['data'];
    if (is_array($message) && isset($data['data']['title'])) {
        $message = $data['data']['title'];
    }

    $status = 'FAILED';
    if ($data['success']) {
        $status = 'SUCCESS';
    }

    $date = new DateTime();
    $date = $date->format("d/m/Y H:i:s");

    $txt = "$date $link => $status => $message";

    try {
        file_put_contents(MUVI_PATH . 'log.txt', $txt . PHP_EOL, FILE_APPEND | LOCK_EX);
        $return = true;
    } catch (\Throwable $th) {
        $return = false;
    }

    return $return;
}
