<?php

require_once(MUVI_PATH . 'controllers/ScrapeController.php');
require_once(MUVI_PATH . 'controllers/MovieController.php');
require_once(MUVI_PATH . 'controllers/TVController.php');

/*
|--------------------------------------------------------------------------
| Ajax Form Handler
|--------------------------------------------------------------------------
*/

add_action('wp_ajax_send_form', 'ajax_send_form');
add_action('wp_ajax_nopriv_send_form', 'ajax_send_form');

function ajax_send_form()
{
    check_ajax_referer('muvigrabber_ajax1039', 'security');
    header('Content-Type: application/json; charset=utf-8');
    $return = [];

    switch ($_POST['type']) {
        case 'get_api':
            $return = get_option('muvigrabber_apikey');
            break;

        case 'get_data':
            if (!isset($_POST['data']) && !is_array($_POST['data'])) {
                wp_die("Membutuhkan parameter 'data'");
            }

            $source = $_POST['data'];
            $movie = get_option('muvigrabber_movie_source');
            $tv = get_option('muvigrabber_tv_source');

            $movie_host = null;
            $tv_host = null;
            foreach ($source as $s) {
                if ($s['type'] === 'movie' && $s['sitename'] === $movie) {
                    $movie_host = $s['host'];
                }

                if ($s['type'] === 'tv' && $s['sitename'] === $tv) {
                    $tv_host = $s['host'];
                }
            }

            $return = [
                'movie' => ['host' => $movie_host, 'sitename' => $movie],
                'tv' => ['host' => $tv_host, 'sitename' => $tv],
            ];
            break;

        case 'get_post':
            if (!isset($_POST['url']) || !isset($_POST['source'])) {
                wp_die("Membutuhkan parameter 'source' dan 'url'");
            }

            $sitename = sanitize_text_field(wp_unslash($_POST['source']));
            $url = sanitize_text_field(wp_unslash($_POST['url']));
            $return = scrape('get', $url, $sitename);
            break;

        case 'scrape':
            if (!isset($_POST['url']) || !isset($_POST['sitename'])) {
                wp_die("Membutuhkan parameter 'url' dan 'sitename'");
            }

            $url = sanitize_text_field(wp_unslash($_POST['url']));
            $sitename = sanitize_text_field(wp_unslash($_POST['sitename']));
            $return = scrape('dashboard', $url, $sitename);
            break;

        case 'upload_post':
            if (!isset($_POST['post_type']) || !isset($_POST['url'])) {
                wp_die("Membutuhkan parameter 'post_type', 'url'");
            }
            $post_type = sanitize_text_field(wp_unslash($_POST['post_type']));
            $url = sanitize_text_field(wp_unslash($_POST['url']));
            $return = null;

            if ($post_type == 'movie') {
                $return = movieReupload($url);
            } elseif ($post_type == 'tv' && !$_POST['clipboard']) {
                $return = TVReupload($url);
            } elseif ($post_type == 'tv' && $_POST['clipboard']) {
                $return = TVReupload($url, true);
            }

            break;

        default:
            wp_die("Terjadi kesalahan");
            break;
    }

    echo json_encode($return);
    wp_die();
}
