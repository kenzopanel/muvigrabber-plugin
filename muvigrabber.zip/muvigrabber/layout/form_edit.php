<style>
    .mt-0 {
        margin-top: 0;
    }

    .mt-3 {
        margin-top: 1em;
    }

    .muvi-box {
        gap: 1em;
    }

    .muvi-flex {
        gap: .5em;
    }

    .muvi-box,
    .muvi-flex {
        display: flex;
        flex-direction: column;
    }
</style>
<div class="muvi-box">
    <div class="form-select muvi-flex mt-3">
        <label for="post-type">Post Type</label>
        <div>
            <select id="post-type">
                <option value="" selected disabled>- Post Type -</option>
                <option value="movie">Movie</option>
                <option value="tv">Series</option>
                <option value="episode">Episode</option>
            </select>
        </div>
    </div>
    <div class="form-select muvi-flex">
        <label for="source">Sumber Konten</label>
        <div>
            <select id="source">
                <option value="" selected disabled>- Sumber Konten -</option>
            </select>
        </div>
    </div>
    <div class="muvi-flex">
        <label for="url">Link Sumber Konten</label>
        <input id="url" type="text" autocomplete="off">
    </div>
    <div class="btn">
        <button type="button" id="update" class="button button-primary display-block">Update Data</button>
    </div>
</div>