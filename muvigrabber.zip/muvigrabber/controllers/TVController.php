<?php

require_once(MUVI_PATH . 'app/helper.php');

/**
 *Upload TV Content
 */
function TVUpload(array $data)
{
    $tv = getPost($data['title'], 'tv');
    if ($tv) {
        return [
            "tmdb" => $tv->IDMUVICORE_tmdbID
        ];
    }

    $args = [
        "post_title" => $data["title"],
        "post_type" => 'tv',
        "post_name" => $data["slug"],
        "post_content" => @$data["synopsis"],
        "post_status" => "publish",
        "post_author" => get_current_user_id(),
    ];

    $post = wp_insert_post($args);

    if (is_wp_error($post)) {
        return [
            "error" => "Series with title " . $data["title"] . " failed to post",
        ];
    }

    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title', $data['title']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Trailer', @$data['trailer']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbVotes', @$data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbRating', @$data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbID', $data['tmdb']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Released', @$data['posted']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Runtime', @$data['duration']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Year', @$data['year']);

    check_meta_terms($post, 'wp_set_post_terms', 'post_tag', @$data['genre']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvidirector', @$data['director']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicast', @$data['actor']);
    check_meta_terms($post, 'wp_set_post_terms', 'muviyear', @$data['year']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicountry', @$data['country']);

    if ($data['genre'] && !empty($data['genre'])) {
        $categories_id = [];
        foreach ($data['genre'] as $category) {
            $category_id = intval(term_exists($category, 'category')['term_id']);
            if (!$category_id) {
                $category_id = wp_create_category($category);
            }
            array_push($categories_id, $category_id);
        }
        wp_set_post_categories($post, $categories_id);
    }

    $attachment_path = downloadImage($data['poster']);
    setThumbnail($attachment_path, $post);

    return [
        'id' => $post,
        'title' => $data["title"],
        'tmdb' => $data['tmdb'],
    ];
}
