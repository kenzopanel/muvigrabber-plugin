<link rel="stylesheet" href="<?= MUVI_URL . 'assets/bootstrap.min.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/muvigrabber.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/style.css' ?>">
<div class="wrap">
    <h1 class="text-slate-800 text-[2rem] leading-10 pb-3 font-semibold text-left wp-heading-inline">Muvi Grabber</h1>
    <hr class="wp-header-end">
    <main>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-none d-md-block">
            <form action="<?= esc_html(admin_url('admin-post.php')); ?>" method="POST">
                <?php
                wp_nonce_field('acme-settings-save', 'acme-custom-message');
                ?>
                <section class="border-b border-solid border-slate-200 px-8 py-8 justify-between">
                    <div class="mr-16 w-full flex items-center">
                        <h3 class="p-0 flex-1 justify-right inline-flex text-xl leading-6 font-semibold text-slate-800">API Key</h3>
                        <input type="text" id="apikey" name="apikey" autocomplete="off" value="<?= $key ?>" required style="min-width:50%">
                    </div>
                    <p class="mt-2 w-9/12 text-sm text-slate-500 tablet:w-full">Masukkan API Key Anda</p>
                </section>
                <button type="submit" class="btn btn-primary btn-sm mt-3 px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white">Simpan perubahan</button>
            </form>
        </div>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-sm-block d-md-none">
            <p class="text-slate-800 text-lg font-semibold text-center">Fitur ini hanya tersedia pada mode landscape</p>
        </div>
    </main>
</div>