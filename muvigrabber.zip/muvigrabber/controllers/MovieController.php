<?php

require_once(MUVI_PATH . 'app/helper.php');
require_once(MUVI_PATH . 'controllers/ScrapeController.php');

/*
|--------------------------------------------------------------------------
| Scrape Detail Movie LK21
|--------------------------------------------------------------------------
*/

function lk21Scrape(string $url)
{
    $data = [];
    $content = getContent($url);

    preg_match_all('!<figure>\s?<img src="(.*?)" alt="(.*?)"!mi', $content, $match);
    $data['poster'] = $match[1][0];
    $data['title'] = html_entity_decode($match[2][0]);
    $data['slug'] = slugify($data['title']);

    preg_match_all('!<figure>\s?<img src=".*?" alt=".*?\((\d\d\d\d)\)"!mi', $content, $match);
    $data['year'] = $match[1][0];

    preg_match_all('!<h2>Kualitas<\/h2><h3><a href=".*?" rel="category" title=".*?">(.*?)<\/a><\/h3>!mi', $content, $match);
    $data['quality'] = $match[1][0];

    preg_match_all('!<h2>Negara<\/h2><h3><a href=".*?" rel="category" title=".*?">(.*?)<\/a><\/h3>!mi', $content, $match);
    $data['country'] = $match[1][0];

    preg_match_all('!<a href=".*?\/artist\/.*?" rel="tag">(.*?)<\/a>!mi', $content, $match);
    $data['actor'] = $match[1];

    preg_match_all('!<a href=".*?\/director\/.*?" rel="tag">(.*?)<\/a>!mi', $content, $match);
    $data['director'] = $match[1];

    preg_match_all('!<h2>Genre<\/h2>(.*?)<h2>IMDb<\/h2>!mi', $content, $match);
    $genreContent = $match[1][0];
    preg_match_all('!<a href=".*?\/genre\/.*?" rel="category".*?>(.*?)<\/a>!mi', $genreContent, $match);
    $data['genre'] = $match[1];

    preg_match_all('!<h2>Durasi<\/h2><h3>(.*?) menit<\/h3>!mi', $content, $match);
    $data['duration'] = $match[1][0];

    preg_match_all('!<h2>IMDb<\/h2><h3>(.*?)<\/h3>.*?<h3>10<\/h3> from <h3>(.*?)<\/h3> users<\/div>!mi', $content, $match);
    $data['score'] = $match[1][0];
    $data['voters'] = $match[2][0];

    preg_match_all('!<a href="(https:\/\/www\.youtube.*?)" rel="nofollow" target="_blank" class="fancybox"><i class="fa-video"><\/i> TRAILER<\/a>!mi', $content, $match);
    $data['trailer'] = $match[1][0];

    preg_match_all("!<blockquote><strong>Synopsis<\/strong><br \/>(.*?)<span class='hidden'>!mi", $content, $match);
    $data['synopsis'] = $match[1][0];

    preg_match_all('!<ul class="list-unstyled dropdown-menu dropdown-menu-right" id="loadProviders">.*?<\/ul>!mi', $content, $match);
    $streamEl = $match[0][0];

    preg_match_all('!<li><a href="(.*?)" target="iframe" class=".*?" rel="(.*?)"><i class="fa fa-server"><\/i>(.*?)<\/a>!mi', $streamEl, $match);
    $streamArr = $match;

    $stream = [];
    foreach ($streamArr[1] as $key => $link) {
        $stream[] = [
            'player' => "{$streamArr[3][$key]} {$streamArr[2][$key]}",
            'link' => $link
        ];
    }
    $data['stream'] = $stream;

    preg_match_all('!<p><a href="https?:(.*?)" class="btn btn-primary btn-block" target="_blank"> <i class="fa-download"><\/i> Download Film Ini<\/a><\/p>!mi', $content, $match);
    $dlPage = $match[1][0];
    $occurence = 3;
    $dlPage = preg_replace("/^((?:(?:.*?\/){" . --$occurence . "}.*?))\//", "$1/get/", $dlPage);
    $dlPage = str_replace("//", "https://", $dlPage);

    $dlContent = getContent($dlPage);
    preg_match("!setCookie\('validate', '(.*?)'\);!", $dlContent, $match);
    $validate = $match[1];
    $dlVerify = getContent("https://dl.makimbo.xyz/verifying.php?slug=$slug", $validate, $slug);
    preg_match_all('!<strong>(.*?)<\/strong><\/td>\n?.*?<td align="center">\n?.*?<a\n?.*?.*?href=(.*?) \D!mi', $dlVerify, $match);
    $dlArr = $match;

    $download = [];
    foreach ($dlArr[1] as $key => $server) {
        $download[] = [
            'server' => $server,
            'link' => str_replace(['"', "'"], "", $dlArr[2][$key]),
        ];
    }
    $data['download'] = $download;

    return $data;
}

/*
|--------------------------------------------------------------------------
| Scrape and Upload Movie Content
|--------------------------------------------------------------------------
*/

function movieReupload(string $url)
{
    if (get_option('muvigrabber_uploaded_movie')) {
        $get = get_option('muvigrabber_uploaded_movie');
        $uploaded = json_decode($get, true);
        $slug = trim(parse_url($url)['path'], '/');
        if (isset($uploaded[$slug])) {
            return muvi_send_error(["error" => "Movie with link $url already posted"]);
        }
    }

    $sitename = get_option('muvigrabber_movie_source');
    $scrape = scrape('post', $url, $sitename);
    $movie = movieUpload($scrape, $url);

    if ($movie['error']) {
        return muvi_send_error($movie['error']);
    }

    return muvi_send_success($movie);
}

/*
|--------------------------------------------------------------------------
| Upload Movie Content
|--------------------------------------------------------------------------
*/

function movieUpload(array $data, string $url = null)
{
    if (getPost($data['title'], 'post')) {
        return ["error" => "Movie with title " . $data["title"] . " is exist"];
    }

    $args = [
        "post_title" => $data["title"],
        "post_type" => 'posts',
        "post_name" => $data["slug"],
        "post_content" => $data["synopsis"],
        "post_status" => "publish",
        "post_author" => get_current_user_id(),
    ];

    $post = wp_insert_post($args);

    if (is_wp_error($post)) {
        return ["error" => "Movie with title " . $data["title"] . " failed to post"];
    }

    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Runtime', $data['duration']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Year', $data['year']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Rated', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title', $data['title']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Trailer', $data['trailer']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbVotes', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbRating', $data['voters']);

    $tags = [
        "Download {$data['title']} Subtitle Indonesia",
        "Unduh {$data['title']} Subtitle Indonesia",
        "Streaming {$data['title']} Subtitle Indonesia",
        "Nonton {$data['title']} Subtitle Indonesia",
    ];

    check_meta_terms($post, 'wp_set_post_terms', 'post_tag', $tags);
    check_meta_terms($post, 'wp_set_post_terms', 'muvidirector', $data['director']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicast', $data['actor']);
    check_meta_terms($post, 'wp_set_post_terms', 'muviyear', $data['year']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicountry', $data['country']);
    check_meta_terms($post, 'wp_set_post_terms', 'muviquality', $data['quality']);

    if ($data['genre'] && !empty($data['genre'])) {
        $categories_id = [];
        foreach ($data['genre'] as $category) {
            $category_id = intval(term_exists($category, 'category')['term_id']);
            if (!$category_id) {
                $category_id = wp_create_category($category);
            }
            array_push($categories_id, $category_id);
        }
        wp_set_post_categories($post, $categories_id);
    }

    $attachment_path = downloadImage($data['poster']);
    setThumbnail($attachment_path, $post);

    if (is_string($url)) {
        $uploaded = [];
        if (get_option('muvigrabber_uploaded_movie')) {
            $get = get_option('muvigrabber_uploaded_movie');
            $uploaded = json_decode($get, true);
        }

        $slug = trim(parse_url($url)['path'], '/');
        $uploaded[] = $slug;
        $json = json_encode($uploaded);

        if (get_option('muvigrabber_uploaded_movie')) {
            update_option('muvigrabber_uploaded_movie', $json);
        } else {
            add_option('muvigrabber_uploaded_movie', $json);
        }
    }

    return [
        'id' => $post,
        'title' => $data["title"],
    ];
}
