<?php

require_once(MUVI_PATH . 'app/helper.php');
require_once(MUVI_PATH . 'controllers/TVController.php');

/*
|--------------------------------------------------------------------------
| Upload Episode Content
|--------------------------------------------------------------------------
*/

function EpisodeUpload(array $data)
{
    $data['title'] = preg_replace("!– | \(\d\d\d\d\)$!i", '', $data['title']);
    if (getPost($data['title'], 'episode')) {
        return ["error" => "Episode with title " . $data["title"] . " is exist"];
    }

    $tmdb = time();
    if (@$data['imdb']) {
        $tmdb = $data['imdb'];
    }

    // Cek apakah sudah ada Parent TV
    $mainTitle = preg_replace("! season \d\d?| episode \d\d?\d?!i", '', $data['title']);
    $tv = getPost($mainTitle, 'tv');
    if ($tv) {
        if ($tv->IDMUVICORE_tmdbID) {
            $tmdb = $tv->IDMUVICORE_tmdbID;
        }
    } else {
        $data['title'] = $mainTitle;
        $data['tmdb'] = $tmdb;
        $tvUpload = TVUpload($data);
        if (!$tvUpload || isset($tvUpload['error'])) {
            return ["error" => "Series with title $mainTitle failed to post"];
        }
    }

    preg_match("!season (\d+) episode (\d+)$!i", $data['title'], $match);
    $seasonNum = $match[1];
    $epsNum = $match[2];

    $args = [
        "post_title" => $data["title"],
        "post_type" => 'episode',
        "post_name" => $data["slug"],
        "post_content" => @$data["synopsis"],
        "post_status" => "publish",
        "post_author" => get_current_user_id(),
    ];

    $post = wp_insert_post($args);

    if (is_wp_error($post)) {
        return ["error" => "Episode with title " . $data["title"] . " failed to post"];
    }

    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title', $data['title']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbVotes', @$data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbRating', @$data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Sessionnumber', $seasonNum);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Episodenumber', $epsNum);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbID', $tmdb);
    check_meta_terms($post, 'wp_set_post_terms', 'muviquality', @$data['quality']);

    foreach ($data['stream'] as $key => $d) {
        check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title_Player' . $key + 1, $d['player']);
        check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Player' . $key + 1, $d['link']);
    }

    if ($data['download']) {
        foreach ($data['download'] as $key => $d) {
            check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title_Download' . $key + 1, $d['server']);
            check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Download' . $key + 1, $d['link']);
        }
    }

    return [
        'id' => $post,
        'title' => $data["title"],
    ];
}
