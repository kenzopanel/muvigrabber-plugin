<?php

require_once(MUVI_PATH . 'app/settings.php');
require_once(MUVI_PATH . 'controllers/AjaxController.php');
require_once(MUVI_PATH . 'controllers/DashboardController.php');
require_once(MUVI_PATH . 'controllers/MovieController.php');
add_post_type_support('tv', 'thumbnail');
date_default_timezone_set('Asia/Jakarta');

/*
|--------------------------------------------------------------------------
| Create Admin Menu and Page
|--------------------------------------------------------------------------
*/

add_action('admin_menu', 'custom_menu');

function custom_menu()
{
    add_menu_page(
        'Muvi Grabber',
        'Muvi Grabber',
        'publish_posts',
        'muvigrabber',
        'tools_page',
        'dashicons-superhero',
        7
    );

    add_submenu_page(
        'muvigrabber',
        'Settings',
        'Settings',
        'manage_options',
        'muvigrabber-settings',
        'settings_page'
    );
}

function tools_page()
{
    include MUVI_PATH . './layout/content.php';
}

function settings_page()
{
    $auto = get_option('muvigrabber_auto');
    $key = get_option('muvigrabber_apikey');
    $movie = get_option('muvigrabber_movie_source');
    $tv = get_option('muvigrabber_tv_source');

    if (!empty(get_option('muvigrabber_auto'))) {
        $auto = 'checked';
    }

    $proxy = '';
    if (get_option('muvigrabber_proxy')) {
        $proxy = get_option('muvigrabber_proxy');
        $proxy = unserialize($proxy);
        $proxy = implode("\n", $proxy);
    }

    ob_start();
    include MUVI_PATH . './layout/settings.php';
    $output = ob_get_clean();
    echo $output;
}

/*
|--------------------------------------------------------------------------
| Attach Admin Assets Files
|--------------------------------------------------------------------------
*/

function custom_wp_admin_style($hook)
{
    // wp_enqueue_style('bootstrap', MUVI_URL . 'assets/bootstrap.min.css');
    // wp_enqueue_style('muvigrabber_style', MUVI_URL . 'assets/muvigrabber.css');
    // wp_enqueue_style('muvigrabber_custom', MUVI_URL . 'assets/style.css');
    wp_enqueue_script('jquery');
    wp_enqueue_script('muvigrabber_script', MUVI_URL . 'assets/script.js', array('jquery'));

    $jsVar = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'ajax_nonce' => wp_create_nonce("muvigrabber_ajax1039"),
    );

    wp_localize_script('muvigrabber_script', 'muvigrabber', $jsVar);
}

add_action('admin_enqueue_scripts', 'custom_wp_admin_style');

/*
|--------------------------------------------------------------------------
| Add Meta Box
|--------------------------------------------------------------------------
*/

$path = $_SERVER['REQUEST_URI'];
$path = preg_replace("!\?.*!", '', $path);
$path = explode('/', $path);
if (isset($path[2]) && $path[2] === 'post.php') {
    function add_meta_boxes_muvigrabber()
    {
        add_meta_box('muvigrabber_box', 'Muvigrabber', 'load_form', 'post', 'normal', 'high');
    }

    add_action('add_meta_boxes', 'add_meta_boxes_muvigrabber');

    function load_form()
    {
        include MUVI_PATH . 'layout/form_edit.php';
    }
}

/*
|--------------------------------------------------------------------------
| Create Rest Route
|--------------------------------------------------------------------------
*/

function muvi_create_rest_route()
{
    register_rest_route('muvigrabber/v1', 'queue/(?P<api_key>.+)', [
        'methods' => 'POST',
        'callback' => 'muvi_add_queue',
    ]);
}

add_action('rest_api_init', 'muvi_create_rest_route');

function muvi_add_queue($request)
{
    $trueApiKey = get_option('muvigrabber_apikey');
    $apiKey = $request->get_param('api_key');
    $newQueue = $request['queue'];

    if ($apiKey === $trueApiKey) {
        if (get_option('muvigrabber_queue')) {
            $oldQueue = get_option('muvigrabber_queue');
            $queueArr = json_decode($oldQueue, true);
            foreach ($newQueue as $value) {
                $queueArr['queue'][] = $value;
            }
            $queueArr = array_values(array_unique($queueArr));
            $count = count($queueArr['queue']);
            $queue = $json = json_encode($queueArr);
            update_option('muvigrabber_queue', $json);
        } else {
            $count = count($newQueue);
            $queue = json_encode($newQueue);
            add_option('muvigrabber_queue', $queue);
        }

        $response = [
            'success' => true,
            'all queues' => $count
        ];
    } else {
        $response = [
            'success' => false,
            'message' => 'Invalid API Key'
        ];
    }

    return new WP_REST_Response($response);
}

/*
|--------------------------------------------------------------------------
| Create Cron Job
|--------------------------------------------------------------------------
*/

add_filter('cron_schedules', 'add_cron_interval');
function add_cron_interval($schedules)
{
    $schedules['hourly'] = array(
        'interval'  => 3600, // time in seconds
        'display'   => 'Every Hour'
    );
    return $schedules;
}

function activate_muvigrab_cron_job()
{
    if (!wp_next_scheduled('muvigrabber_cron_job')) {
        wp_schedule_event(time(), 'hourly', 'muvigrabber_cron_job');
    }
}

add_action('muvigrabber_cron_job', 'muvigrab_cj_callback');

function muvigrab_cj_callback()
{
    if (get_option('muvigrabber_queue')) {
        $q = get_option('muvigrabber_queue');
        $queue = json_decode($q, true);
        $qArr = $queue['queue'];
        $getQueue = array_slice($qArr, 0, 10);
        $slicedQueue = array_slice($qArr, 10);

        $movieSitename = get_option('muvigrabber_movie_source');
        $tvSitename = get_option('muvigrabber_tv_source');

        $failQueue = [];
        foreach ($getQueue as $value) {
            $upload = [
                'success' => false,
                'data' => 'FAILED UPLOAD'
            ];

            if ($value['type'] === 'movie') {
                if ($value['sitename'] === $movieSitename) {
                    $upload = movieReupload($value['link']);
                }
            } elseif ($value['type'] === 'tv') {
                if ($value['sitename'] === $tvSitename) {
                    $upload = TVReupload($value['link'], true);
                }
            } else {
                continue;
            }

            $args = [
                'post_title' => $value['link']
            ];

            wp_insert_post($args);

            muvi_logger($value['link'], $upload);

            if ($upload['success'] === false) {
                $fail = [
                    'link' => $value['link'],
                    'type' => $value['type'],
                    'sitename' => $value['sitename'],
                ];

                $failQueue[] = $fail;
            }
        }

        foreach ($failQueue as $value) {
            $newQueue['queue'][] = $value;
        }

        foreach ($slicedQueue as $value) {
            $newQueue['queue'][] = $value;
        }

        $json = json_encode($newQueue);
        update_option('muvigrabber_queue', $json);
        muvi_logger('CRON JOB', ['success' => true, 'data' => 'Berhasil menjalankan cron job']);
    }
}

function deactivate_muvigrab_cron_job()
{
    wp_clear_scheduled_hook('muvigrabber_cron_job');
}

/*
|--------------------------------------------------------------------------
| Plugin Update
|--------------------------------------------------------------------------
*/

add_filter('plugins_api', 'plugin_info', 20, 3);

function plugin_info($res, $action, $args)
{
    if ('plugin_information' !== $action) {
        return $res;
    }

    if (MUVI_BASEDIR !== $args->slug) {
        return $res;
    }

    $remote = wp_remote_get(
        'https://github.com/kenzopanel/muvigrabber-plugin/raw/main/info.json',
        array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            )
        )
    );

    if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
        return $res;
    }

    $remote = json_decode(wp_remote_retrieve_body($remote));

    $res = new stdClass();
    $res->name = $remote->name;
    $res->slug = $remote->slug;
    $res->author = $remote->author;
    $res->author_profile = $remote->author_profile;
    $res->version = $remote->version;
    $res->tested = $remote->tested;
    $res->requires = $remote->requires;
    $res->requires_php = $remote->requires_php;
    $res->download_link = $remote->download_url;
    $res->trunk = $remote->download_url;
    $res->last_updated = $remote->last_updated;
    $res->sections = array(
        'description' => $remote->sections->description,
        'installation' => $remote->sections->installation,
        'changelog' => $remote->sections->changelog
    );

    return $res;
}

add_filter('site_transient_update_plugins', 'plugin_push_update');

function plugin_push_update($transient)
{
    if (empty($transient->checked)) {
        return $transient;
    }

    $remote = wp_remote_get(
        'https://github.com/kenzopanel/muvigrabber-plugin/raw/main/info.json',
        array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            )
        )
    );

    if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
        return $transient;
    }

    $remote = json_decode(wp_remote_retrieve_body($remote));

    if (
        $remote
        && version_compare('1.0.0', $remote->version, '<')
        && version_compare($remote->requires, get_bloginfo('version'), '<')
        && version_compare($remote->requires_php, PHP_VERSION, '<')
    ) {

        $res = new stdClass();
        $res->slug = $remote->slug;
        $res->plugin = MUVI_BASEFILE;
        $res->new_version = $remote->version;
        $res->tested = $remote->tested;
        $res->package = $remote->download_url;
        $transient->response[$res->plugin] = $res;

        //$transient->checked[$res->plugin] = $remote->version;
    }

    return $transient;
}
