<?php

/**
 * Plugin Name: Muvi Grabber
 * Description: Movie & Series Content Grabber only for Muvipro Theme
 * Version: 1.0.0
 * Author: Z
 * Author URI:  https://t.me/kenzo_id
 */

// Abort if this file is called directly
if (!defined('WPINC') || !defined('ABSPATH')) exit;

define('MUVI_PATH', plugin_dir_path(__FILE__));
define('MUVI_URL', plugin_dir_url(__FILE__));
define('MUVI_BASEDIR', plugin_basename(__DIR__));
define('MUVI_BASEFILE', plugin_basename(__FILE__));

require_once(MUVI_PATH . 'app/app.php');
register_activation_hook(__FILE__, 'activate_muvigrabber');
register_deactivation_hook(__FILE__, 'deactivate_muvigrabber');
register_uninstall_hook(__FILE__, 'uninstall_muvigrabber');
