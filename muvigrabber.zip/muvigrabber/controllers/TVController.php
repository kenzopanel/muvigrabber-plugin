<?php

require_once(MUVI_PATH . 'app/helper.php');
require_once(MUVI_PATH . 'controllers/ScrapeController.php');
require_once(MUVI_PATH . 'controllers/EpisodeController.php');

/*
|--------------------------------------------------------------------------
| Scrape Detail TV Nonton Drama
|--------------------------------------------------------------------------
*/

function nontonDramaScrape(string $url, $alleps = false)
{
    $data = [];
    $content = getContent($url);

    preg_match_all('!<figure>\s?<img src="(.*?)" alt="(.*?)"!mi', $content, $match);
    $data['poster'] = $match[1][0];
    $title = preg_replace("!&#8211; Season .*? Episode .*? !i", '', $match[2][0]);
    $data['title'] = html_entity_decode($title);
    $data['slug'] = slugify($data['title']);

    preg_match_all('!<figure>\s?<img src=".*?" alt=".*?\((\d\d\d\d)\)"!mi', $content, $match);
    $data['year'] = $match[1][0];

    preg_match_all('!<h2>Diterbitkan<\/h2><h3>(.*?)<\/h3>!mi', $content, $match);
    $data['date'] = $match[1][0];

    preg_match_all('!<h2>Negara<\/h2><h3><a href=".*?" rel="category" title=".*?">(.*?)<\/a><\/h3>!mi', $content, $match);
    $data['country'] = $match[1][0];

    preg_match_all('!<a href=".*?\/artist\/.*?" rel="tag">(.*?)<\/a>!mi', $content, $match);
    $data['actor'] = $match[1];

    preg_match_all('!<a href=".*?\/director\/.*?" rel="tag">(.*?)<\/a>!mi', $content, $match);
    $data['director'] = $match[1];

    preg_match_all('!<h2>Genre<\/h2>(.*?)<h2>!mi', $content, $match);
    $genreContent = $match[1][0];
    preg_match_all('!<a href=".*?\/genre\/.*?" rel="category".*?\>(.*?)<\/a>!mi', $genreContent, $match);
    $data['genre'] = $match[1];

    preg_match_all('!<h2>Durasi<\/h2><h3>\s?(.*?) menit\s?<\/h3>!mi', $content, $match);
    $data['duration'] = $match[1][0];


    preg_match_all('!<h2>IMDb<\/h2><h3>(.*?)<\/h3>.*?<h3>10<\/h3> from <h3>(.*?)<\/h3> users<\/div>!mi', $content, $match);
    $data['score'] = $match[1][0];
    $data['voters'] = $match[2][0];

    preg_match_all('!<iframe .*? src="https:\/\/www\.youtube\.com\/embed\/(.*?)"!mi', $content, $match);
    if (isset($match[1][0])) {
        $data['trailer'] = "https://www.youtube.com/watch?v={$match[1][0]}";
    }

    preg_match_all("!<blockquote><strong>Synopsis<\/strong><br \/>(.*?)<span class='hidden'>!mi", $content, $match);
    $data['synopsis'] = $match[1][0];

    preg_match_all('!"https?:\/\/(.*?)\/(.*?)-season-.*?-episode.*?"!mi', $content, $match);
    $host = $match[1][1];
    $post_name = $match[2][1];

    $pattern = '"(https?:\/\/' . $host . '\/' . $post_name . '-season-(.*?)-episode-(.*?)-.*?)"';
    preg_match_all("!$pattern!mi", $content, $match);

    if ($alleps) {
        // Ambil semua episode
        $data['eps'] = $match[1];
    } else {
        // Ambil episode terakhir
        $data['eps'] = $match[1][0];
    }

    return $data;
}

/*
|--------------------------------------------------------------------------
| Scrape TMDB ID
|--------------------------------------------------------------------------
*/

function scrapeTMDBID($title, $year)
{
    $url = "https://www.themoviedb.org/search/tv?query=$title%20y%3A$year";
    $content = getContent($url);

    preg_match('!<a data-id=.*?href="\/tv\/(.*?)"><h2>.*?<\/a>\n?.*\n\n?.*release_date">.*<.*?!mi', $content, $match);
    if ($match[1]) {
        return $match[1];
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| Scrape and Upload TV Content
|--------------------------------------------------------------------------
*/

function TVReupload(string $url, $alleps = false)
{
    $sitename = get_option('muvigrabber_tv_source');
    if ($alleps) {
        $sitename = "$sitename-alleps";
    }

    $scrape = scrape('post', $url, $sitename);
    $tv = TVUpload($scrape);

    if ($tv['error'] && !is_array($alleps) && $tv['code'] !== 'is_exist') {
        return muvi_send_error($tv['error']);
    }

    if ($tv['error'] && is_array($alleps) && $tv['code'] !== 'tmdb_notfound') {
        return muvi_send_error($tv['error']);
    }

    if ($alleps) {
        $eps = EpisodesReupload($tv['eps'], $tv['tmdb'], $alleps);
    } else {
        $eps = EpisodeReupload($tv['eps'], $tv['tmdb']);
    }

    $data = [
        'title' => $tv['title'],
        'eps' => $eps,
    ];

    return muvi_send_success($data);
}

/*
|--------------------------------------------------------------------------
| Upload TV Content
|--------------------------------------------------------------------------
*/

function TVUpload(array $data)
{
    $titleFiltered = preg_replace("!\s\(\d\d\d\d\)\z!", '', $data['title']);
    $titleFiltered = str_replace(" ", "%20", $titleFiltered);
    $tmdb = scrapeTMDBID($titleFiltered, $data['year']);

    if (getPost($data['title'], 'tv')) {
        return [
            "error" => "Series with title " . $data["title"] . " is exist",
            "code" => "is_exist",
            "tmdb" => $tmdb,
        ];
    }

    if (!$tmdb) {
        return [
            "error" => "Couldn't find series with title " . $data["title"] . " in TMDB",
            "code" => "tmdb_notfound",
        ];
    }

    $args = [
        "post_title" => $data["title"],
        "post_type" => 'tv',
        "post_name" => $data["slug"],
        "post_content" => $data["synopsis"],
        "post_status" => "publish",
        "post_author" => get_current_user_id(),
    ];

    $post = wp_insert_post($args);

    if (is_wp_error($post)) {
        return [
            "error" => "Series with title " . $data["title"] . " failed to post",
            "code" => "failed_post",
        ];
    }

    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Runtime', $data['duration']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Year', $data['year']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Rated', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title', $data['title']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Trailer', $data['trailer']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbVotes', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbRating', $data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbID', $tmdb);

    $tags = [
        "Download {$data['title']} Subtitle Indonesia",
        "Unduh {$data['title']} Subtitle Indonesia",
        "Streaming {$data['title']} Subtitle Indonesia",
        "Nonton {$data['title']} Subtitle Indonesia",
    ];

    check_meta_terms($post, 'wp_set_post_terms', 'post_tag', $tags);
    check_meta_terms($post, 'wp_set_post_terms', 'muvidirector', $data['director']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicast', $data['actor']);
    check_meta_terms($post, 'wp_set_post_terms', 'muviyear', $data['year']);
    check_meta_terms($post, 'wp_set_post_terms', 'muvicountry', $data['country']);

    if ($data['genre'] && !empty($data['genre'])) {
        $categories_id = [];
        foreach ($data['genre'] as $category) {
            $category_id = intval(term_exists($category, 'category')['term_id']);
            if (!$category_id) {
                $category_id = wp_create_category($category);
            }
            array_push($categories_id, $category_id);
        }
        wp_set_post_categories($post, $categories_id);
    }

    $attachment_path = downloadImage($data['poster']);
    setThumbnail($attachment_path, $post);

    return [
        'id' => $post,
        'title' => $data["title"],
        'tmdb' => $tmdb,
        'eps' => $data['eps'],
    ];
}
