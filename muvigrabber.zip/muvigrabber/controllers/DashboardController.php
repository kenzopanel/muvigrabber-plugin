<?php

require_once(MUVI_PATH . 'app/helper.php');

/*
|--------------------------------------------------------------------------
| LK21 dan Nonton Drama Scrape Dashboard
|--------------------------------------------------------------------------
*/

function lk21ListScrape(string $host, string $sitename)
{
    $url = "$host/latest/";
    $content = getContent($url);

    preg_match_all('!<h1 class="grid-title"><a href="(.*?)".*?<\/cite>(.*?)<!mi', $content, $match);
    $link = null;
    if ($match[1]) {
        $link = $match[1];
    }

    $title = null;
    if ($match[2]) {
        $title = $match[2];
        $title = preg_replace("!\tSeason \d!i", '', $title);
    }

    preg_match_all('!<img.*?src="(.*?)"><\/a><div class="grid-meta">!mi', $content, $match);
    $poster = null;
    if ($match[1]) {
        $poster = $match[1];
    }

    if ($sitename === 'nonton-drama') {
        preg_match_all('!<div class="last-episode.*?">EPS<span>(.*?)<\/span>!mi', $content, $match);
        $eps = null;
        if ($match[1]) {
            $eps = $match[1];
        }
    }

    $merge = [];
    if (is_array($title) && is_array($poster) && is_array($link)) {
        foreach ($title as $key => $t) {
            $data = [
                'title' => $t,
                'poster' => $poster[$key],
                'link' => $link[$key],
            ];

            if ($sitename === 'nonton-drama' && is_array($eps)) {
                $data['eps'] = $eps[$key];
            }

            $merge[] = $data;
        }
    }

    return $merge;
}
