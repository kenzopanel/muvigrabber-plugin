<link rel="stylesheet" href="<?= MUVI_URL . 'assets/bootstrap.min.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/muvigrabber.css' ?>">
<link rel="stylesheet" href="<?= MUVI_URL . 'assets/style.css' ?>">
<div class="wrap">
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="text-slate-800 text-[2rem] leading-10 pb-3 font-semibold text-left wp-heading-inline">Muvi Grabber</h1>
        <div class="d-none d-md-block">
            <button type="button" id="upload-post" class="btn btn-primary btn-sm">Upload Post (<span class="total">0</span>)</button>
        </div>
    </div>
    <hr class="wp-header-end">
    <div class="max-w-3xl mx-auto py-3 lg:max-w-7xl rounded">
        <div class="alert alert-warning">
            <p class="text-base"><b>Perhatian!</b> Menambahkan konten dengan fitur ini dapat membuat duplikat konten dengan fitur autopost</p>
            <p class="text-base">Jangan menutup tab ketika proses uploading!</p>
            <p class="text-base">Hanya bisa upload konten sesuai dengan pemilihan sumber web pada pengaturan plugin</p>
        </div>
        <div class="alert alert-warning tv-alert hide">
            <p class="text-base">Menambahkan konten dengan Post Type <b>TV</b> akan menambah <b>1 Episode Terakhir dari Season Terakhir</b></p>
        </div>
        <div class="alert alert-warning clipboard-alert hide">
            <p class="text-base">Hanya bisa menambahkan konten dengan Post Type sejenis</p>
            <p class="text-base">Menambahkan konten dengan Post Type <b>TV</b> akan menambah <b>seluruh Season dan Episode</b></p>
        </div>
        <div id="result" class="alert alert-light hide"></div>
    </div>
    <main>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-none d-md-block">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex flex-row gap-3" id="posttype-opt">
                    <button type="button" class="btn btn-active py-2 px-4 font-semibold" data-type="movie" disabled>Movie</button>
                    <button type="button" class="btn btn-option py-2 px-4 font-semibold" data-type="tv">Series</button>
                    <button type="button" class="btn btn-option py-2 px-4 font-semibold" data-type="clipboard">From URLs</button>
                </div>
            </div>
            <div class="d-flex flex-wrap mt-4 justify-content-center" id="muvigrab-content">
                <span class="loader"></span>
            </div>
            <div id="clipboard-wrapper" class="hide">
                <div class="form-group mb-3">
                    <select id="post-type" class="form-control mt-1" required style="max-width: 10rem;">
                        <option value="" disabled selected>- Post Type -</option>
                        <option value="movie">Movie</option>
                        <option value="tv">TV</option>
                    </select>
                </div>
                <div class="form-floating">
                    <textarea class="form-control" placeholder="Put your link here" id="link"></textarea>
                    <label for="link">Put your links here. One link each row</label>
                </div>
                <button type="button" id="upload-clipboard" class="btn btn-primary btn-sm mt-3 px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white">Upload Post</button>
            </div>
        </div>
        <div class="max-w-3xl mx-auto px-6 py-3 lg:max-w-7xl bg-white rounded d-sm-block d-md-none">
            <p class="text-slate-800 text-lg font-semibold text-center">Fitur ini hanya tersedia pada mode Landscape</p>
        </div>
    </main>
</div>