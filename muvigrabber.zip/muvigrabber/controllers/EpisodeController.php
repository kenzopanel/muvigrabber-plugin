<?php

require_once(MUVI_PATH . 'app/helper.php');
require_once(MUVI_PATH . 'controllers/ScrapeController.php');

/*
|--------------------------------------------------------------------------
| Scrape Episode Nonton Drama
|--------------------------------------------------------------------------
*/

function nontonDramaScrapeEps(string $url)
{
    $data = [];
    $content = getContent($url);

    preg_match_all('!<figure>\s?<img src="(.*?)" alt="(.*?) \(.*?"!mi', $content, $match);
    $data['poster'] = $match[1][0];
    $title = str_replace("&#8211; ", '', $match[2][0]);
    $data['title'] = html_entity_decode($title);
    $data['slug'] = slugify($data['title']);

    preg_match_all('!Season (.*?) Episode (.*?)\z!mi', $data['title'], $match);
    $data['season_num'] = $match[1][0];
    $data['episode_num'] = $match[2][0];

    preg_match_all('!<h2>Kualitas<\/h2><h3><a href=".*?quality.*?" rel="category" title=".*?">(.*?)<\/a><\/h3>!mi', $content, $match);
    $data['quality'] = $match[1][0];

    preg_match_all("!<blockquote><strong>Synopsis<\/strong><br \/>(.*?)<span class='hidden'>!mi", $content, $match);
    $data['synopsis'] = $match[1][0];

    preg_match_all('!<ul class="list-unstyled dropdown-menu dropdown-menu-right" id="loadProviders">.*?<\/ul>!mi', $content, $match);
    $streamEl = $match[0][0];

    preg_match_all('!<li><a href="(.*?)" target="iframe" class=".*?" rel="(.*?)"><i class="fa fa-server"><\/i>(.*?)<\/a>!mi', $streamEl, $match);
    $streamArr = $match;

    $stream = [];
    foreach ($streamArr[1] as $key => $link) {
        $stream[] = [
            'player' => "{$streamArr[3][$key]} {$streamArr[2][$key]}",
            'link' => $link
        ];
    }
    $data['stream'] = $stream;

    preg_match_all('!<p><a href="https?:(.*?)" class="btn btn-primary btn-block" target="_blank"> <i class="fa-download"><\/i> Download Film Ini<\/a><\/p>!mi', $content, $match);
    $dlPage = $match[1][0];
    $occurence = 3;
    $dlPage = preg_replace("/^((?:(?:.*?\/){" . --$occurence . "}.*?))\//", "$1/get/", $dlPage);
    $dlPage = str_replace("//", "https://", $dlPage);

    $dlContent = getContent($dlPage);
    preg_match("!setCookie\('validate', '(.*?)'\);!", $dlContent, $match);
    $validate = $match[1];
    $slug = trim(parse_url($url, PHP_URL_PATH), '/');
    $dlVerify = getContent("https://dl.makimbo.xyz/verifying.php?slug=$slug", $validate, $slug);
    preg_match_all('!<strong>(.*?)<\/strong><\/td>\n?.*?<td align="center">\n?.*?<a\n?.*?.*?href=(.*?) \D!mi', $dlVerify, $match);
    $dlArr = $match;

    $download = [];
    foreach ($dlArr[1] as $key => $server) {
        $download[] = [
            'server' => $server,
            'link' => str_replace(['"', "'"], "", $dlArr[2][$key]),
        ];
    }
    $data['download'] = $download;

    return $data;
}

/*
|--------------------------------------------------------------------------
| Scrape and Upload Last Episode Content
|--------------------------------------------------------------------------
*/

function EpisodeReupload(string $url, string $tmdb)
{
    if (get_option('muvigrabber_uploaded_eps')) {
        $get = get_option('muvigrabber_uploaded_eps');
        $uploaded = json_decode($get, true);
        $slug = trim(parse_url($url)['path'], '/');
        if (isset($uploaded[$slug])) {
            return muvi_send_error(["error" => "Eps with link $url already posted"]);
        }
    }

    $sitename = get_option('muvigrabber_tv_source');
    $scrape = scrape('post', $url, "$sitename-eps");
    $data = EpisodeUpload($scrape, $tmdb);

    return $data;
}

/*
|--------------------------------------------------------------------------
| Scrape and Upload All Episode Content
|--------------------------------------------------------------------------
*/

function EpisodesReupload(array $episodes, string $tmdb, $alleps)
{
    $data = [];
    $sitename = get_option('muvigrabber_tv_source');
    $urls = $episodes;
    if (is_array($alleps)) {
        $urls = $alleps;
    }

    $filtered = $urls;
    if (get_option('muvigrabber_uploaded_eps')) {
        $get = get_option('muvigrabber_uploaded_eps');
        $slug = json_decode($get, true);
        $slugOld = preg_replace("!https?:\/\/.*?\/!", '', $urls);
        $slugOld = preg_replace("!\/!", '', $slugOld);
        $filtered = array_diff($slugOld, $slug);
    }

    if (empty($filtered)) {
        return false;
    }

    foreach ($filtered as $eps) {
        $scrape = scrape('post', $eps, "$sitename-eps");
        $data[] = EpisodeUpload($scrape, $tmdb, $eps);
    }

    return $data;
}

/*
|--------------------------------------------------------------------------
| Upload Episode Content
|--------------------------------------------------------------------------
*/

function EpisodeUpload(array $data, string $tmdb, string $url = null)
{
    if (getPost($data['title'], 'episode')) {
        return ["error" => "Episode with title " . $data["title"] . " is exist"];
    }

    $args = [
        "post_title" => $data["title"],
        "post_type" => 'episode',
        "post_name" => $data["slug"],
        "post_content" => $data["synopsis"],
        "post_status" => "publish",
        "post_author" => get_current_user_id(),
    ];

    $post = wp_insert_post($args);

    if (is_wp_error($post)) {
        return ["error" => "Episode with title " . $data["title"] . " failed to post"];
    }

    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Title', $data['title']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Rated', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbVotes', $data['score']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbRating', $data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Sessionnumber', $data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_Episodenumber', $data['voters']);
    check_meta_terms($post, 'add_post_meta', 'IDMUVICORE_tmdbID', $tmdb);
    check_meta_terms($post, 'wp_set_post_terms', 'muviquality', $data['quality']);

    if (is_string($url)) {
        $uploaded = [];
        if (get_option('muvigrabber_uploaded_eps')) {
            $get = get_option('muvigrabber_uploaded_eps');
            $uploaded = json_decode($get, true);
        }

        $slug = trim(parse_url($url)['path'], '/');
        $uploaded[] = $slug;
        $json = json_encode($uploaded);

        if (get_option('muvigrabber_uploaded_eps')) {
            update_option('muvigrabber_uploaded_eps', $json);
        } else {
            add_option('muvigrabber_uploaded_eps', $json);
        }
    }

    return [
        'id' => $post,
        'title' => $data["title"],
    ];
}
