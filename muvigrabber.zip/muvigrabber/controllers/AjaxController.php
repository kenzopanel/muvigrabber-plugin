<?php

require_once(MUVI_PATH . 'controllers/MovieController.php');
require_once(MUVI_PATH . 'controllers/TVController.php');

/*
|--------------------------------------------------------------------------
| Ajax Form Handler
|--------------------------------------------------------------------------
*/

add_action('wp_ajax_send_form', 'ajax_send_form');
add_action('wp_ajax_nopriv_send_form', 'please_login');

function ajax_send_form()
{
    check_ajax_referer('muvigrabber_ajax1039', 'security');
    header('Content-Type: application/json; charset=utf-8');

    $apikey = get_option('muvigrabber_apikey');
    $body = [
        'apikey' => $apikey,
        'type' => $_POST['type'],
        'link' => $_POST['link'],
    ];

    $post = wp_remote_post("http://autopost-api.test/api/v1/get-link", ['body' => $body, 'method' => 'POST']);

    if (is_wp_error($post)) {
        echo json_encode([
            'status' => 'failed',
            'error' => $post->get_error_message()
        ]);
        wp_die();
    }

    echo json_encode($post);
    wp_die();
}

function please_login()
{
    echo "You must log in to use this feature!";
    die();
}
