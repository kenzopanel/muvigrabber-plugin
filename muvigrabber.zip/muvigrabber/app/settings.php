<?php

/*
|--------------------------------------------------------------------------
| Verify Unique Nonce
|--------------------------------------------------------------------------
*/

function has_valid_nonce()
{
    if (!isset($_POST['acme-custom-message'])) {
        return false;
    }
    $field  = wp_unslash($_POST['acme-custom-message']);
    $action = 'acme-settings-save';
    return wp_verify_nonce($field, $action);
}

/*
|--------------------------------------------------------------------------
| Save Plugin Settings
|--------------------------------------------------------------------------
*/

function save_settings()
{
    if ((has_valid_nonce() && current_user_can('manage_options'))) {
        if (wp_unslash($_POST['apikey']) !== null && wp_unslash($_POST['movie']) !== null && wp_unslash($_POST['tv']) !== null) {
            $movie = sanitize_text_field($_POST['movie']);
            $tv = sanitize_text_field($_POST['tv']);
            $apikey = sanitize_text_field($_POST['apikey']);
            $autoupdate = 'false';
            if (isset($_POST['autoupdate'])) {
                $autoupdate = 'true';
            }

            $proxy = '';
            if (isset($_POST['proxy'])) {
                $proxy = sanitize_text_field($_POST['proxy']);
                $proxy = explode(" ", $proxy);
                $proxy = serialize($proxy);
            }

            if (!empty($movie) && !empty($tv) && !empty($apikey)) {
                if (get_option('muvigrabber_movie_source')) {
                    update_option('muvigrabber_movie_source', $movie);
                } else {
                    add_option('muvigrabber_movie_source', $movie);
                }

                if (get_option('muvigrabber_tv_source')) {
                    update_option('muvigrabber_tv_source', $tv);
                } else {
                    add_option('muvigrabber_tv_source', $tv);
                }

                if (get_option('muvigrabber_apikey')) {
                    update_option('muvigrabber_apikey', $apikey);
                } else {
                    add_option('muvigrabber_apikey', $apikey);
                }

                if (get_option('muvigrabber_auto')) {
                    update_option('muvigrabber_auto', $autoupdate);
                } else {
                    add_option('muvigrabber_auto', $autoupdate);
                }

                if (get_option('muvigrabber_proxy')) {
                    update_option('muvigrabber_proxy', $proxy);
                } else {
                    add_option('muvigrabber_proxy', $proxy);
                }
            }

            wp_redirect($_SERVER['HTTP_REFERER']);
            exit;
        }
    }
}

add_action('admin_post', 'save_settings');
